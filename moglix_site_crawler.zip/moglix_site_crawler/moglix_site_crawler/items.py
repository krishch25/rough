# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DbUpsertItem(scrapy.Item):
    """
    Generic wrapper item for DB upserts from spiders.

    Spiders should set:
      - db_table: target table name
      - db_on_conflict: ON CONFLICT key(s) for upsert (string like "url" or "col1,col2")
      - db_payload: dict of column -> value for the row
    """

    db_table = scrapy.Field()
    db_on_conflict = scrapy.Field()
    db_payload = scrapy.Field()


class MoglixCategoryUpsertItem(DbUpsertItem):
    """Upsert wrapper for a Moglix category record."""


class MoglixListingPageUpsertItem(DbUpsertItem):
    """Upsert wrapper for a single listing page evidence record."""


class MoglixProductRawUpsertItem(DbUpsertItem):
    """Upsert wrapper for a single product summary record."""


class MoglixRepairTaskUpsertItem(DbUpsertItem):
    """
    Upsert wrapper for a repair task triggered by completeness verification.

    Example:
      - db_table = "moglix_repair_tasks"
      - db_on_conflict = "category_url,page_number"
      - db_payload includes status="needs_repair" + evidence fields
    """
