import json
import logging
import os
from typing import Any, Dict, List

from itemadapter import ItemAdapter
from supabase import create_client

logger = logging.getLogger(__name__)


class SupabaseMoglixPipeline:
    """
    Writes Scrapy output into NEW Supabase tables.

    Contract (set by spiders):
      - item["db_table"]: target table name
      - item["db_on_conflict"]: upsert key(s) string (e.g. "url" or "category_url,page_number")
      - item["db_payload"]: dict of columns -> values
    """

    def __init__(self):
        self.supabase = None
        self.batch_size = int(os.environ.get("SUPABASE_PIPELINE_BATCH_SIZE", "50"))
        self._batch: Dict[str, List[Dict[str, Any]]] = {}
        self._conflicts: Dict[str, str] = {}

    @classmethod
    def from_crawler(cls, crawler):
        return cls()

    def open_spider(self, spider):
        supabase_url = os.environ.get("SUPABASE_URL", "")
        supabase_key = os.environ.get("SUPABASE_KEY", "")

        if not supabase_url or not supabase_key:
            raise RuntimeError(
                "Missing SUPABASE_URL / SUPABASE_KEY env vars for Scrapy Supabase pipeline."
            )

        self.supabase = create_client(supabase_url, supabase_key)
        logger.info("SupabaseMoglixPipeline initialized")

    def process_item(self, item, spider):
        if self.supabase is None:
            return item

        adapter = ItemAdapter(item)
        table = adapter.get("db_table")
        on_conflict = adapter.get("db_on_conflict")
        payload = adapter.get("db_payload")

        if not table or not isinstance(payload, dict):
            logger.warning("Skipping item: missing db_table or invalid db_payload")
            return item

        self._batch.setdefault(table, []).append(payload)
        if on_conflict:
            self._conflicts[table] = on_conflict

        total_rows = sum(len(v) for v in self._batch.values())
        if total_rows >= self.batch_size:
            self._flush()

        return item

    def close_spider(self, spider):
        self._flush()

    def _flush(self):
        if self.supabase is None or not self._batch:
            return

        for table, rows in list(self._batch.items()):
            on_conflict = self._conflicts.get(table)
            try:
                query = self.supabase.table(table).upsert(
                    rows, on_conflict=on_conflict
                ) if on_conflict else self.supabase.table(table).insert(rows)
                query.execute()
                logger.info("Supabase write OK: %d rows -> %s", len(rows), table)
            except Exception as e:
                logger.error("Supabase write failed table=%s: %s", table, str(e))
                debug_dir = os.environ.get("MOG_SCRAPY_DEBUG_DIR", "/tmp/moglix_scrapy_debug")
                os.makedirs(debug_dir, exist_ok=True)
                debug_path = os.path.join(debug_dir, f"supabase_write_failed_{table}.json")
                try:
                    with open(debug_path, "w", encoding="utf-8") as f:
                        json.dump(rows[:5], f, ensure_ascii=False, default=str, indent=2)
                except Exception:
                    pass
            finally:
                self._batch[table] = []

        self._batch = {k: v for k, v in self._batch.items() if v}
