import asyncio
import json
import logging
import random
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BASE_URL = "https://www.moglix.com"

# Same high-signal API endpoints your FastAPI/Playwright interceptor watches.
MOGLIX_API_PATTERNS = [
    "/product/getProductGroupDetails",
    "/search/searchProducts",
    "/category/getSubcategories",
    "/product/getProductData",
    "api.moglix.com",
    "/moglixSearchV2/",
]

USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
]


async def capture_listing_evidence(
    page_url: str,
    intercept_patterns: Optional[List[str]] = None,
    wait_until: str = "domcontentloaded",
    timeout_ms: int = 45000,
) -> Dict[str, Any]:
    """
    Capture raw HTML + intercepted JSON responses for a listing page.

    This is intended to run only for `needs_repair` tasks (undercount pages).
    """

    try:
        from playwright.async_api import async_playwright
    except ModuleNotFoundError as e:
        raise RuntimeError(
            "playwright is not installed in this environment. Install dependencies for moglix_site_crawler."
        ) from e

    intercept_patterns = intercept_patterns or MOGLIX_API_PATTERNS
    intercepted: List[Dict[str, Any]] = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=True,
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
        )

        context = await browser.new_context(
            user_agent=random.choice(USER_AGENTS),
            viewport={"width": 1920, "height": 1080},
            locale="en-IN",
            timezone_id="Asia/Kolkata",
        )

        # Block heavy assets for speed.
        await context.route(
            "**/*.{png,jpg,jpeg,gif,svg,webp,mp4,woff,woff2}",
            lambda route: route.abort(),
        )

        await context.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>false})"
        )

        page = await context.new_page()

        async def capture_response(response):
            try:
                url = response.url or ""
                if not any(p in url for p in intercept_patterns):
                    return

                ct = response.headers.get("content-type", "")
                if "json" not in ct:
                    return

                body = await response.json()
                intercepted.append({"url": url, "status": response.status, "data": body})
            except Exception:
                # Never fail the entire capture for an intercepted parse issue.
                return

        page.on("response", capture_response)

        await page.goto(page_url, wait_until=wait_until, timeout=timeout_ms)
        # Optional stabilization wait.
        await page.wait_for_timeout(1000)

        html = await page.content()
        await browser.close()

    return {
        "url": page_url,
        "html": html,
        "intercepted": intercepted,
        "captured_at": datetime.utcnow().isoformat(),
    }


def capture_listing_evidence_sync(page_url: str) -> Dict[str, Any]:
    """Synchronous wrapper for CLI/worker usage."""
    return asyncio.run(capture_listing_evidence(page_url))

