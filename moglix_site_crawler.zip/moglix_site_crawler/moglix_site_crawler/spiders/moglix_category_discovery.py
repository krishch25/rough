from typing import Iterable, Optional, Set

import scrapy

from ..items import MoglixCategoryUpsertItem
from ..utils_moglix import category_level_from_url, category_name_from_url, normalize_category_url


class MoglixCategoryDiscoverySpider(scrapy.Spider):
    """
    Recursive discovery spider.

    It starts at the Moglix homepage and repeatedly:
      - Extracts likely category listing URLs from anchor tags
      - Yields an upsert item for each discovered category
      - Follows category URLs to discover additional subcategories

    Notes:
      - Category hierarchy is heuristic (parent_url is the page that contained the link).
      - A later “AI repair” stage can fix taxonomy accuracy if needed.
    """

    name = "moglix_category_discovery"

    custom_settings = {
        "CONCURRENT_REQUESTS": 24,
        "DOWNLOAD_DELAY": 0.5,
        "AUTOTHROTTLE_ENABLED": True,
        "ROBOTSTXT_OBEY": False,
    }

    def __init__(
        self,
        start_url: str = "https://www.moglix.com/",
        max_pages: int = 50000,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.start_url = start_url
        self.max_pages = int(max_pages)
        self._seen: Set[str] = set()
        self._visited_pages = 0

    def start_requests(self) -> Iterable[scrapy.Request]:
        yield scrapy.Request(self.start_url, callback=self.parse_category_page)

    def parse_category_page(self, response: scrapy.http.Response):
        if self._visited_pages >= self.max_pages:
            self.logger.warning("Reached max_pages=%s, stopping discovery", self.max_pages)
            return

        self._visited_pages += 1

        hrefs = response.css("a::attr(href)").getall()
        parent_url = response.url

        for href in hrefs:
            category_url = normalize_category_url(href)
            if not category_url:
                continue
            if category_url in self._seen:
                continue

            self._seen.add(category_url)

            yield self._to_category_item(category_url, parent_url=parent_url)

            # Keep discovering only while under max_pages.
            if self._visited_pages < self.max_pages:
                yield scrapy.Request(
                    category_url,
                    callback=self.parse_category_page,
                    dont_filter=True,
                )

    def _to_category_item(self, category_url: str, parent_url: Optional[str]) -> MoglixCategoryUpsertItem:
        name = category_name_from_url(category_url)
        level = category_level_from_url(category_url)

        payload = {
            "url": category_url,
            "name": name,
            "parent_url": parent_url,
            "level": level,
            "path": category_url.rsplit("/", 1)[0].split("://", 1)[-1],
            "source": "recursive_discovery",
        }

        return MoglixCategoryUpsertItem(
            db_table="moglix_categories",
            db_on_conflict="url",
            db_payload=payload,
        )

