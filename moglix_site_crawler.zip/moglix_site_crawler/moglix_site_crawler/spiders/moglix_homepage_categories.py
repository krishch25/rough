from typing import Iterable, Optional, Set
from urllib.parse import urlparse

import scrapy

from ..items import MoglixCategoryUpsertItem
from ..utils_moglix import (
    category_name_from_url,
    category_level_from_url,
    normalize_category_url,
)


class MoglixHomepageCategoriesSpider(scrapy.Spider):
    """
    Seed spider: finds first-wave category listing URLs from Moglix homepage HTML.

    It does NOT try to be perfect; a follow-up recursive spider can expand discovery.
    """

    name = "moglix_homepage_categories"

    custom_settings = {
        # Category discovery can generate many requests; keep it conservative for seeds.
        "CONCURRENT_REQUESTS": 16,
        "DOWNLOAD_DELAY": 1.0,
        "AUTOTHROTTLE_ENABLED": True,
        "ROBOTSTXT_OBEY": False,
    }

    def __init__(
        self,
        start_url: str = "https://www.moglix.com/",
        max_links: int = 5000,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.start_url = start_url
        self.max_links = int(max_links)
        self._seen: Set[str] = set()

    def start_requests(self) -> Iterable[scrapy.Request]:
        yield scrapy.Request(self.start_url, callback=self.parse_home)

    def parse_home(self, response: scrapy.http.Response):
        # Collect all anchor tags and filter to likely category listing URLs.
        hrefs = response.css("a::attr(href)").getall()
        for href in hrefs:
            url = normalize_category_url(href)
            if not url:
                continue
            if url in self._seen:
                continue

            self._seen.add(url)

            yield self._to_category_item(url)

            if len(self._seen) >= self.max_links:
                self.logger.warning("Reached max_links=%s, stopping seed discovery", self.max_links)
                return

    def _to_category_item(self, category_url: str) -> MoglixCategoryUpsertItem:
        name = category_name_from_url(category_url)
        level = category_level_from_url(category_url)

        parsed = urlparse(category_url)
        # parent_url is not reliably available without breadcrumb/API;
        # keep it null for now and let the recursive spider (or AI repair) improve it later.
        parent_url: Optional[str] = None

        # We upsert by URL so repeated runs are idempotent.
        payload = {
            "url": category_url,
            "name": name,
            "parent_url": parent_url,
            "level": level,
            "path": parsed.path.rsplit("/", 1)[0].strip("/"),
            "source": "homepage_seed",
        }

        return MoglixCategoryUpsertItem(
            db_table="moglix_categories",
            db_on_conflict="url",
            db_payload=payload,
        )

