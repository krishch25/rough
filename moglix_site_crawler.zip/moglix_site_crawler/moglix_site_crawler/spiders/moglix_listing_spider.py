import re
from typing import Dict, Iterable, List, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse

import scrapy

from ..items import MoglixListingPageUpsertItem, MoglixProductRawUpsertItem
from ..items import MoglixRepairTaskUpsertItem


BASE_URL = "https://www.moglix.com"

# Example header from Moglix:
#   "Showing 40 out of 3812 Products"
_SHOWING_RE = re.compile(
    r"Showing\s+(?P<on_page>\d+)\s+out\s+of\s+(?P<total>\d+)\s+Products",
    re.IGNORECASE,
)


def _build_paginated_url(category_url: str, page_num: int) -> str:
    # Replace page= if present
    if re.search(r"(?:\?|&)page=\d+", category_url):
        return re.sub(r"(?:\?|&)page=\d+", f"page={page_num}", category_url, flags=re.IGNORECASE)
    join_char = "&" if "?" in category_url else "?"
    return f"{category_url}{join_char}page={page_num}"


def _extract_showing_counts(text: str) -> Tuple[Optional[int], Optional[int]]:
    m = _SHOWING_RE.search(text or "")
    if not m:
        return None, None
    return int(m.group("on_page")), int(m.group("total"))


def _normalize_url(href: str) -> Optional[str]:
    if not href:
        return None
    if href.startswith("//"):
        return "https:" + href
    if href.startswith("/"):
        return urljoin(BASE_URL, href)
    if href.startswith("http://") or href.startswith("https://"):
        return href
    return None


def _extract_products_from_html(response: scrapy.http.Response, limit: int = 200) -> List[Dict[str, Optional[str]]]:
    """
    Extract product summaries from listing HTML.

    For robustness we do two passes:
      1) DOM anchors with '/mp/' in href
      2) Regex fallback on '/mp/' URLs
    """
    products: List[Dict[str, Optional[str]]] = []
    seen_urls: Set[str] = set()

    # Pass 1: anchor hrefs
    for a in response.css("a[href*='/mp/']")[:400]:
        href = a.attrib.get("href", "")
        product_url = _normalize_url(href)
        if not product_url or "/mp/" not in product_url:
            continue

        # Link text is usually the product title.
        name = " ".join(t.strip() for t in a.css("::text").getall() if t and t.strip())
        # Cleanup: remove very short/garbage nodes.
        name = re.sub(r"\s+", " ", name).strip()
        if len(name) < 4:
            name = None

        if product_url in seen_urls:
            continue
        seen_urls.add(product_url)

        products.append(
            {
                "product_url": product_url,
                "name": name,
                "brand": None,
            }
        )
        if len(products) >= limit:
            break

    # Pass 2: regex only if pass1 found nothing (or near-nothing).
    if len(products) < 5:
        for m in re.finditer(r"https?://www\.moglix\.com/[^\"']+/mp/[^\"']+", response.text or ""):
            product_url = m.group(0)
            if product_url in seen_urls:
                continue
            seen_urls.add(product_url)
            products.append({"product_url": product_url, "name": None, "brand": None})
            if len(products) >= limit:
                break

    return products


class MoglixListingSpider(scrapy.Spider):
    """
    Crawl paginated Moglix category listing pages and upsert:
      - moglix_listing_pages (one row per crawled page)
      - moglix_products_raw (one row per product summary)
    """

    name = "moglix_listing"

    custom_settings = {
        "CONCURRENT_REQUESTS": 16,
        "DOWNLOAD_DELAY": 0.4,
        "AUTOTHROTTLE_ENABLED": True,
        "ROBOTSTXT_OBEY": False,
    }

    def __init__(
        self,
        category_url: str = "",
        max_pages: int = 200,
        undercount_threshold_ratio: float = 0.8,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        if not category_url:
            raise ValueError("category_url is required. Example: -a category_url='https://www.moglix.com/.../211520000'")
        self.category_url = category_url.rstrip()
        self.max_pages = int(max_pages)
        self.undercount_threshold_ratio = float(undercount_threshold_ratio)

        self._seen_products: Set[str] = set()

    def start_requests(self) -> Iterable[scrapy.Request]:
        yield scrapy.Request(self._build_paginated_url(1), callback=self.parse_page, meta={"page_num": 1})

    def _build_paginated_url(self, page_num: int) -> str:
        return _build_paginated_url(self.category_url, page_num)

    def parse_page(self, response: scrapy.http.Response):
        page_num = int(response.meta.get("page_num", 1))
        raw_text = response.text or ""

        extraction_strategy_id = "listing_extractor_v1"

        on_page_expected, total_expected = _extract_showing_counts(raw_text)

        page_products = _extract_products_from_html(response)

        extracted_count = len(page_products)
        expected_count = on_page_expected
        is_undercount = False
        if expected_count is not None and expected_count > 0:
            is_undercount = extracted_count < int(expected_count * self.undercount_threshold_ratio)

        # Store listing page evidence
        raw_html_trunc = raw_text[:50000]  # keep bounded
        status = "ok"
        if extracted_count == 0:
            status = "empty"
        elif is_undercount:
            status = "undercount"

        yield MoglixListingPageUpsertItem(
            db_table="moglix_listing_pages",
            db_on_conflict="category_url,page_number",
            db_payload={
                "category_url": self.category_url,
                "page_number": page_num,
                "expected_on_page": expected_count,
                "total_products": total_expected,
                "extracted_count": extracted_count,
                "status": status,
                "raw_html_truncated": raw_html_trunc,
                "extraction_strategy_id": extraction_strategy_id,
                "source_url": response.url,
            },
        )

        if status == "undercount":
            # Mark a repair task so a separate worker can use Playwright + AI to fix extraction.
            yield MoglixRepairTaskUpsertItem(
                db_table="moglix_repair_tasks",
                db_on_conflict="category_url,page_number",
                db_payload={
                    "category_url": self.category_url,
                    "page_number": page_num,
                    "status": "needs_repair",
                    "expected_on_page": expected_count,
                    "total_products": total_expected,
                    "extracted_count": extracted_count,
                    "initial_extraction_strategy_id": extraction_strategy_id,
                    "evidence_listing_page_url": response.url,
                    "raw_html_truncated": raw_html_trunc,
                    "source_url": response.url,
                },
            )

        # Store product summaries
        for p in page_products:
            product_url = p.get("product_url")
            if not product_url or product_url in self._seen_products:
                continue
            self._seen_products.add(product_url)

            yield MoglixProductRawUpsertItem(
                db_table="moglix_products_raw",
                db_on_conflict="product_url",
                db_payload={
                    "product_url": product_url,
                    "name": p.get("name"),
                    "brand": p.get("brand"),
                    "category_url": self.category_url,
                    "listing_page": page_num,
                    "source_url": product_url,
                },
            )

        # Decide whether to continue pagination
        if extracted_count == 0:
            # If this happens once, try one more page; then stop.
            # (Most categories eventually stop producing product links.)
            if page_num >= 3:
                return

        if page_num >= self.max_pages:
            self.logger.warning("Reached max_pages=%s, stopping", self.max_pages)
            return

        if total_expected is not None and on_page_expected is not None and on_page_expected > 0:
            per_page_est = on_page_expected
            total_pages = (total_expected + per_page_est - 1) // per_page_est
            if page_num >= total_pages + 1:
                return

        next_page = page_num + 1
        yield scrapy.Request(
            self._build_paginated_url(next_page),
            callback=self.parse_page,
            meta={"page_num": next_page},
        )

