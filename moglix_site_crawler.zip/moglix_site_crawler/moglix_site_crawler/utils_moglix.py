import re
from typing import Optional, Tuple
from urllib.parse import urljoin


BASE_URL = "https://www.moglix.com"

# Heuristic for category listing URLs:
#   https://www.moglix.com/{slug}/{slug}/123456789
# where the last segment is a long numeric id (often 9 digits).
_CATEGORY_PATH_RE = re.compile(r"^/[^/]+/[^/]+/\d{6,}$")


def is_category_url(url: str) -> bool:
    path = url
    if url.startswith("http"):
        path = re.sub(r"^https?://[^/]+", "", url)
    return bool(_CATEGORY_PATH_RE.match(path))


def normalize_category_url(href: str) -> Optional[str]:
    if not href:
        return None
    if href.startswith("//"):
        href = "https:" + href
    if href.startswith("/"):
        return urljoin(BASE_URL, href)
    if href.startswith("http://") or href.startswith("https://"):
        if is_category_url(href):
            return href
    return None


def category_name_from_url(url: str) -> str:
    """
    Best-effort category name from URL path.
    Example path: /electricals/power-generation-transformers/211520000
    """
    path = re.sub(r"^https?://[^/]+", "", url).strip("/")
    parts = path.split("/")[:-1]  # drop numeric id
    name = " ".join(parts).replace("-", " ").strip()
    if not name:
        return "Moglix Category"
    # Title-case each token but keep common acronyms short.
    return " ".join(token.capitalize() for token in name.split())


def category_level_from_url(url: str) -> int:
    """
    Heuristic mapping:
      - /a/b/id -> level 1
    (We can refine later using breadcrumb/API data.)
    """
    path = re.sub(r"^https?://[^/]+", "", url).strip("/")
    parts = path.split("/")
    # last part is numeric id
    slug_parts = len(parts) - 1
    return max(1, slug_parts - 1)

