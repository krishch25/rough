import json
import os
import re
import logging
from typing import Any, Dict, List, Optional, Tuple

from supabase import create_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("moglix_ai_director_worker")

BASE_URL = "https://www.moglix.com"


def get_supabase():
    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_KEY", "")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL / SUPABASE_KEY env vars.")
    return create_client(supabase_url, supabase_key)


def _extract_mp_urls_from_html(html: str) -> List[str]:
    if not html:
        return []
    # Absolute URLs
    urls = re.findall(r"https?://www\.moglix\.com/[^\"']+/mp/[^\"']+", html)
    # Relative URLs
    if not urls:
        rel = re.findall(r'href=[\"\'](/[^\"\']+/mp/[^\"\']+)[\"\']', html)
        urls = [BASE_URL + r for r in rel]
    # Dedup preserve order
    seen = set()
    out = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _extract_product_urls_from_json_like(html: str) -> List[str]:
    """
    Attempt to extract product URLs from JSON-ish embedded payloads.
    Works only if listing HTML contains keys like "productUrl".
    """
    if not html:
        return []
    rels = re.findall(r'"productUrl"\s*:\s*"([^"]+)"', html)
    urls: List[str] = []
    for r in rels:
        if not r:
            continue
        if r.startswith("http"):
            urls.append(r)
        elif r.startswith("/"):
            urls.append(BASE_URL + r)
    # Dedup
    seen = set()
    out = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _extract_product_names_near_mp(html: str, limit: int = 200) -> Dict[str, Optional[str]]:
    """
    Best-effort mapping product_url -> name from HTML.
    If HTML doesn't contain easily parseable pairs, returns empty names.
    """
    if not html:
        return {}
    mapping: Dict[str, Optional[str]] = {}

    # Attempt to grab anchor text with mp href.
    for m in re.finditer(r'<a[^>]+href=[\"\']([^\"\']+/mp/[^\"\']+)[\"\'][^>]*>(.*?)</a>', html, flags=re.IGNORECASE | re.DOTALL):
        if len(mapping) >= limit:
            break
        rel = m.group(1)
        href = rel if rel.startswith("http") else (BASE_URL + rel)
        # Strip tags from anchor inner HTML
        inner = m.group(2) or ""
        text = re.sub(r"<[^>]+>", " ", inner)
        text = re.sub(r"\s+", " ", text).strip()
        mapping[href] = text if len(text) >= 4 else None

    return mapping


def _choose_strategy(
    expected_on_page: Optional[int], html: str
) -> Tuple[str, List[str], Dict[str, Optional[str]], Dict[str, int]]:
    """
    Evaluate multiple extraction strategies and choose the one with product count
    closest to expected_on_page (if known).
    """
    # Strategy 1: general mp link extraction
    mp_urls = _extract_mp_urls_from_html(html)
    # Strategy 2: json-ish "productUrl" extraction
    json_urls = _extract_product_urls_from_json_like(html)

    name_map = _extract_product_names_near_mp(html)

    candidates = [
        ("html_mp_regex", mp_urls),
        ("json_productUrl_regex", json_urls),
    ]
    candidate_counts = {k: len(v) for k, v in candidates}

    if expected_on_page is None or expected_on_page <= 0:
        # No expected count: fall back to whichever produced more URLs.
        best = max(candidates, key=lambda x: len(x[1]))
        return best[0], best[1], name_map, candidate_counts

    # Choose the URL list whose length is closest to expected.
    best = min(candidates, key=lambda x: abs(len(x[1]) - expected_on_page))
    return best[0], best[1], name_map, candidate_counts


def main():
    sb = get_supabase()

    limit = int(os.environ.get("MOG_DIRECTOR_WORKER_LIMIT", "10"))
    worker_id = os.environ.get("MOG_DIRECTOR_WORKER_ID", "director_worker")
    completed_expected_ratio = float(os.environ.get("MOG_REPAIR_ACCEPT_RATIO", "0.95"))

    tasks = (
        sb.table("moglix_repair_tasks")
        .select("*")
        .eq("status", "repaired")
        .limit(limit)
        .execute()
    )
    raw_tasks: List[Dict[str, Any]] = tasks.data or []
    logger.info("Fetched %d tasks with status=repaired", len(raw_tasks))

    for t in raw_tasks:
        category_url = t.get("category_url")
        page_number = t.get("page_number")
        expected_on_page = t.get("expected_on_page")
        evidence_html = t.get("repaired_html_truncated") or t.get("repaired_html") or ""
        evidence_listing_page_url = t.get("evidence_listing_page_url")

        if not category_url or page_number is None:
            continue

        try:
            strategy_id, product_urls, name_map, candidate_counts = _choose_strategy(
                expected_on_page=expected_on_page, html=evidence_html
            )
            extracted_count = len(product_urls)

            logger.info(
                "Director pick: category_url=%s page=%s strategy=%s extracted=%s expected=%s",
                category_url,
                page_number,
                strategy_id,
                extracted_count,
                expected_on_page,
            )

            # Upsert extracted products.
            rows = []
            for url in product_urls:
                rows.append(
                    {
                        "product_url": url,
                        "name": name_map.get(url),
                        "brand": None,
                        "category_url": category_url,
                        "listing_page": page_number,
                        "source_url": url,
                        "director_strategy_id": strategy_id,
                    }
                )

            if rows:
                sb.table("moglix_products_raw").upsert(rows, on_conflict="product_url").execute()

            # Decide next status based on completeness acceptance threshold.
            accept = False
            if expected_on_page and expected_on_page > 0:
                accept = extracted_count >= int(expected_on_page * completed_expected_ratio)

            new_task_status = "repaired_ok" if accept else "needs_repair"

            sb.table("moglix_repair_tasks").update(
                {
                    "status": new_task_status,
                    "director_strategy_id": strategy_id,
                    "director_extracted_count": extracted_count,
                    "director_candidate_counts": candidate_counts,
                    "repaired_by_worker": worker_id,
                }
            ).eq("category_url", category_url).eq("page_number", page_number).execute()

            # Also update listing page row status.
            sb.table("moglix_listing_pages").update(
                {
                    "status": new_task_status,
                    "director_strategy_id": strategy_id,
                    "director_extracted_count": extracted_count,
                    "director_candidate_counts": candidate_counts,
                }
            ).eq("category_url", category_url).eq("page_number", page_number).execute()

        except Exception as e:
            logger.exception("Director failed for category_url=%s page=%s", category_url, page_number)
            sb.table("moglix_repair_tasks").update(
                {"status": "director_failed", "repair_error": str(e)[:2000], "director_by_worker": worker_id}
            ).eq("category_url", category_url).eq("page_number", page_number).execute()


if __name__ == "__main__":
    main()

