import os
import logging
from datetime import datetime, timezone

from supabase import create_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("moglix_enqueue_listing_tasks")


def get_supabase():
    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_KEY", "")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL / SUPABASE_KEY env vars.")
    return create_client(supabase_url, supabase_key)


def main():
    sb = get_supabase()

    limit = int(os.environ.get("MOG_ENQUEUE_LIMIT", "5000"))
    task_type = os.environ.get("MOG_CRAWL_TASK_TYPE", "listing")

    categories = (
        sb.table("moglix_categories")
        .select("url")
        .limit(limit)
        .execute()
    )
    cats = categories.data or []
    logger.info("Fetched %d categories from moglix_categories (limit=%d)", len(cats), limit)

    rows = []
    for c in cats:
        url = c.get("url")
        if not url:
            continue
        rows.append(
            {
                "task_type": task_type,
                "target_url": url,
                "status": "pending",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        )

    if not rows:
        logger.info("No categories to enqueue.")
        return

    # Upsert tasks so re-running this script is idempotent.
    sb.table("moglix_crawl_tasks").upsert(rows, on_conflict="task_type,target_url").execute()
    logger.info("Upserted %d listing tasks into moglix_crawl_tasks", len(rows))


if __name__ == "__main__":
    main()

