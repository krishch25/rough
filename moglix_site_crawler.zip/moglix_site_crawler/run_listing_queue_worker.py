import os
import time
import json
import logging
import subprocess
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

from supabase import create_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("moglix_listing_queue_worker")


def get_supabase():
    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_KEY", "")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL / SUPABASE_KEY env vars.")
    return create_client(supabase_url, supabase_key)


def try_claim_task(sb, task_type: str, worker_id: str) -> Optional[Dict[str, Any]]:
    """
    Best-effort claim:
      1) Read a single pending task
      2) Update it to in_progress with a conditional status check
    """
    pending = (
        sb.table("moglix_crawl_tasks")
        .select("id,target_url")
        .eq("task_type", task_type)
        .eq("status", "pending")
        .limit(1)
        .execute()
    )
    task_list = pending.data or []
    if not task_list:
        return None

    task = task_list[0]
    task_id = task.get("id")
    if task_id is None:
        return None

    update = (
        sb.table("moglix_crawl_tasks")
        .update(
            {
                "status": "in_progress",
                "claimed_by_worker": worker_id,
                "claimed_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        .eq("id", task_id)
        .eq("status", "pending")
        .execute()
    )

    # If the conditional update lost the race, update.data may be empty.
    claimed = update.data or []
    if not claimed:
        return None

    # Re-attach target_url for convenience.
    task["target_url"] = task.get("target_url")
    return task


def run_listing_spider(category_url: str, max_pages: int) -> Tuple[bool, str]:
    project_root = os.environ.get(
        "MOG_SCRAPY_PROJECT_ROOT",
        "/Users/krishchoudhary/GITHUB/SCRAPY/scrapy/moglix_site_crawler",
    )

    cmd = [
        "scrapy",
        "crawl",
        "moglix_listing",
        "-a",
        f"category_url={category_url}",
        "-a",
        f"max_pages={max_pages}",
    ]

    logger.info("Running spider: %s", " ".join(cmd))
    proc = subprocess.run(
        cmd,
        cwd=project_root,
        capture_output=True,
        text=True,
    )

    ok = proc.returncode == 0
    out = (proc.stdout or "")[-2000:]
    err = (proc.stderr or "")[-2000:]
    logs = out + ("\n" if out and err else "") + err
    return ok, logs


def main():
    sb = get_supabase()

    task_type = os.environ.get("MOG_CRAWL_TASK_TYPE", "listing")
    worker_id = os.environ.get("MOG_QUEUE_WORKER_ID", "listing_worker_1")
    max_pages = int(os.environ.get("MOG_LISTING_MAX_PAGES", "200"))
    sleep_s = float(os.environ.get("MOG_QUEUE_SLEEP_SECONDS", "10"))

    logger.info("Starting listing queue worker_id=%s task_type=%s", worker_id, task_type)

    while True:
        task = try_claim_task(sb, task_type=task_type, worker_id=worker_id)
        if not task:
            time.sleep(sleep_s)
            continue

        task_id = task.get("id")
        category_url = task.get("target_url")
        if task_id is None or not category_url:
            time.sleep(1)
            continue

        try:
            ok, logs = run_listing_spider(category_url=category_url, max_pages=max_pages)
            if ok:
                sb.table("moglix_crawl_tasks").update(
                    {"status": "completed", "completed_at": datetime.now(timezone.utc).isoformat()}
                ).eq("id", task_id).execute()
            else:
                sb.table("moglix_crawl_tasks").update(
                    {
                        "status": "failed",
                        "failed_at": datetime.now(timezone.utc).isoformat(),
                        "last_error": logs[:2000],
                    }
                ).eq("id", task_id).execute()

        except Exception as e:
            logger.exception("Worker crashed while handling task_id=%s", task_id)
            sb.table("moglix_crawl_tasks").update(
                {
                    "status": "failed",
                    "failed_at": datetime.now(timezone.utc).isoformat(),
                    "last_error": str(e)[:2000],
                }
            ).eq("id", task_id).execute()


if __name__ == "__main__":
    main()

