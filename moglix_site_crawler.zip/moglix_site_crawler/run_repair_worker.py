import os
import json
import logging
from typing import Any, Dict, List

from supabase import create_client

from moglix_site_crawler.repair.playwright_capture import capture_listing_evidence_sync

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("moglix_repair_worker")


def get_supabase():
    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_KEY", "")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL / SUPABASE_KEY env vars.")
    return create_client(supabase_url, supabase_key)


def main():
    sb = get_supabase()

    limit = int(os.environ.get("MOG_REPAIR_WORKER_LIMIT", "5"))
    worker_id = os.environ.get("MOG_REPAIR_WORKER_ID", "repair_worker")

    # Fetch tasks marked as needs_repair.
    tasks = (
        sb.table("moglix_repair_tasks")
        .select("*")
        .eq("status", "needs_repair")
        .order("created_at", desc=False)
        .limit(limit)
        .execute()
    )

    raw_tasks: List[Dict[str, Any]] = tasks.data or []
    logger.info("Fetched %d repair tasks", len(raw_tasks))

    for t in raw_tasks:
        category_url = t.get("category_url")
        page_number = t.get("page_number")
        evidence_url = t.get("evidence_listing_page_url") or t.get("repaired_listing_page_url")

        if not evidence_url:
            logger.warning("Skipping task without evidence_listing_page_url (category_url=%s page=%s)", category_url, page_number)
            continue

        try:
            logger.info("Repairing: category_url=%s page=%s url=%s", category_url, page_number, evidence_url)
            capture = capture_listing_evidence_sync(evidence_url)

            html_trunc = (capture.get("html") or "")[:100000]
            intercepted = capture.get("intercepted") or []

            # Update task as repaired.
            sb.table("moglix_repair_tasks").update(
                {
                    "status": "repaired",
                    "repaired_by_worker": worker_id,
                    "repaired_html_truncated": html_trunc,
                    "repaired_intercepted_json": intercepted,
                }
            ).eq("category_url", category_url).eq("page_number", page_number).execute()

        except Exception as e:
            logger.exception("Repair failed for category_url=%s page=%s", category_url, page_number)
            sb.table("moglix_repair_tasks").update(
                {
                    "status": "repair_failed",
                    "repaired_by_worker": worker_id,
                    "repair_error": str(e)[:2000],
                }
            ).eq("category_url", category_url).eq("page_number", page_number).execute()


if __name__ == "__main__":
    main()

