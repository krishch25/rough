-- Moglix AI worker tables (NEW only)
-- Run this in Supabase/Postgres to support the isolated Scrapy + repair workers.

-- 1) Categories discovered from homepage/recursive category crawling
CREATE TABLE IF NOT EXISTS moglix_categories (
  id BIGSERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  name TEXT,
  parent_url TEXT,
  level INT,
  path TEXT,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT moglix_categories_url_uniq UNIQUE (url)
);

-- 2) Listing pages evidence and completeness status
CREATE TABLE IF NOT EXISTS moglix_listing_pages (
  id BIGSERIAL PRIMARY KEY,
  category_url TEXT NOT NULL,
  page_number INT NOT NULL,

  expected_on_page INT,
  total_products INT,
  extracted_count INT,
  status TEXT NOT NULL DEFAULT 'ok',

  extraction_strategy_id TEXT,
  director_strategy_id TEXT,
  director_extracted_count INT,
  director_candidate_counts JSONB,

  raw_html_truncated TEXT,
  evidence_listing_page_url TEXT,

  repaired_by_worker TEXT,
  repaired_html_truncated TEXT,
  repaired_intercepted_json JSONB,

  ai_factory_rule_id TEXT,
  ai_factory_accepted BOOLEAN,
  ai_factory_extracted_count INT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT moglix_listing_pages_cat_page_uniq UNIQUE (category_url, page_number)
);

-- 3) Product summary rows extracted from listings (raw/staging)
CREATE TABLE IF NOT EXISTS moglix_products_raw (
  id BIGSERIAL PRIMARY KEY,
  product_url TEXT NOT NULL,
  name TEXT,
  brand TEXT,

  category_url TEXT,
  listing_page INT,
  source_url TEXT,

  director_strategy_id TEXT,
  ai_factory_rule_id TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT moglix_products_raw_url_uniq UNIQUE (product_url)
);

-- 4) Repair task queue: created by completeness verifier, filled by Playwright worker, finalized by director/adapter
CREATE TABLE IF NOT EXISTS moglix_repair_tasks (
  id BIGSERIAL PRIMARY KEY,
  category_url TEXT NOT NULL,
  page_number INT NOT NULL,

  status TEXT NOT NULL DEFAULT 'needs_repair',

  expected_on_page INT,
  total_products INT,
  extracted_count INT,

  initial_extraction_strategy_id TEXT,
  evidence_listing_page_url TEXT,
  raw_html_truncated TEXT,

  repaired_by_worker TEXT,
  repaired_html_truncated TEXT,
  repaired_intercepted_json JSONB,

  director_by_worker TEXT,
  director_strategy_id TEXT,
  director_extracted_count INT,
  director_candidate_counts JSONB,

  ai_factory_rule_id TEXT,
  ai_factory_attempt INT NOT NULL DEFAULT 0,
  ai_factory_failed BOOLEAN,
  ai_factory_error_log TEXT,
  ai_factory_extracted_count INT,
  ai_factory_accepted BOOLEAN,

  repair_error TEXT,
  director_failed BOOLEAN,

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT moglix_repair_tasks_cat_page_uniq UNIQUE (category_url, page_number)
);

-- 5) Learned extraction rules (optional but useful for auditing)
CREATE TABLE IF NOT EXISTS moglix_extraction_rules (
  rule_id TEXT PRIMARY KEY,
  category_url TEXT,
  page_number INT,
  html_fingerprint TEXT,
  rule_code TEXT,

  director_strategy_id TEXT,
  extracted_count INT,
  expected_on_page INT,
  accepted BOOLEAN,

  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6) DB-backed crawl tasks for queue workers
CREATE TABLE IF NOT EXISTS moglix_crawl_tasks (
  id BIGSERIAL PRIMARY KEY,
  task_type TEXT NOT NULL, -- e.g. 'listing'
  target_url TEXT NOT NULL,

  status TEXT NOT NULL DEFAULT 'pending', -- pending, in_progress, completed, failed
  claimed_by_worker TEXT,
  claimed_at TIMESTAMPTZ,

  completed_at TIMESTAMPTZ,
  failed_at TIMESTAMPTZ,
  last_error TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT moglix_crawl_tasks_type_url_uniq UNIQUE (task_type, target_url)
);

